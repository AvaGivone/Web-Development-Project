
/*FUNCTION DESCRIPTION: 
This function is what controls the side navigation menu by opening and collapsing 
it upon the user click. */
var menuOpen = false; 
function sideMenu(){
    main = document.getElementById("container");
    menu = document.getElementById("sidemenu");
    console.log(menuOpen);

    if(menuOpen == true){
        main.style.width = "100%";
        menu.style.display = "none";
        menuOpen = false;
    }

    else if(menuOpen == false){
        main.style["width"] = "85%";
        menu.style.display = "block";
        menuOpen = true;
    }
}
